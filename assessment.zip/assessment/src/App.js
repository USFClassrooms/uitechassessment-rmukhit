import React, { Component } from 'react';
import { Link } from 'react-router-dom'

class App extends Component {

    render() {
        return (
            <div>
                <Link to="/list">
                    <button type="button" className="btn btn-primary" >Cart List</button>
                </Link>
                <Link to="/item/add">
                    <button type="button" className="btn btn-primary" >Add Item</button>
                </Link>
            </div>
        );
    }
}

export default App;
