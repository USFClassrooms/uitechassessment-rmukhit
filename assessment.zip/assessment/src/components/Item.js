import React from "react";
import PropTypes from "prop-types";

function Item(props) {
    return (
        <div>
            <span> {props.name} {props.description} {props.price} {props.amount}</span>
        </div>
        );
}

Item.propTypes = {
    name: PropTypes.string.isRequired
};

export default Item;