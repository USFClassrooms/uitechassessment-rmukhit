import React, { Component } from 'react';

import axios from "axios";

import CartList from "./CartList";

class Cart extends Component {

    state = {
        cartList: []
    };

    componentDidMount() {
        axios.get('http://localhost:5555/list')
            .then(response => {

                // create an array of contacts only with relevant data
                const newItems = response.data.map(c => {
                    return {
                        id: c.id,
                        name: c.name,
                        description: c.description,
                        price: c.price,
                        amount: c.amount
                    };
                });

                // create a new "State" object without mutating
                // the original State object.
                const newState = Object.assign({}, this.state, {
                    cartList: newItems
                });

                // store the new state object in the component's state
                this.setState(newState);
            })
            .catch(error => console.log(error));
    }


    render() {
        return (
            <div>
                <CartList cartList = {this.state.cartList} />
            </div>
        );
    }
}

export default Cart;
