import React, { Component } from 'react';

class AddItem extends Component {
    constructor(props) {
        super(props)
        this.state = {
            Name: '',
            Description: '',
            Price: '',
            Amount: ''
        };
        this.addName = this.addName.bind(this);
        this.addDescription = this.addDescription.bind(this);
        this.addPrice = this.addPrice.bind(this);
        this.addAmount = this.addAmount.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);


    }

    addName(event) {
        this.setState({Name: event.target.value});
    }
    addDescription(event) {
        this.setState({Description: event.target.value});
    }
    addPrice(event) {
        this.setState({Price: event.target.value});
    }
    addAmount(event) {
        this.setState({Amount: event.target.value});
    }

    handleSubmit(event) {
        event.preventDefault();

        let name = this.state.Name;
        let desc = this.state.Description;
        let price = this.state.Price;
        let amount = this.state.Amount;

        console.log(JSON.stringify({name:name, description:desc, price:price, amount:amount}));

        const json = JSON.stringify({name:name, description:desc, price:price, amount:amount})

        fetch('http://localhost:5555/item/add', {
            method: 'POST',
            mode: 'no-cors',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'text/plain',
            },
            body: json
        }).then(res => res.json()).catch(err => console.log(err));

    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <label>Item name: </label>
                <input id="name" name="Name" type="text" value={this.state.Name} onChange={this.addName}/>

                <label>Description: </label>
                <input id="description" name="Description" type="text" value={this.state.Description} onChange={this.addDescription}/>

                <label>Price: </label>
                <input id="price" name="Price" type="number" value={this.state.Price} onChange={this.addPrice}/>

                <label>Amount: </label>
                <input id="amount" name="Amount" type="number" value={this.state.Amount} onChange={this.addAmount}/>

                <button type="submit">Add Item</button>
            </form>
        );
    }
}
export default AddItem