import React from "react";

import Item from "./Item";

function CartList(props) {
    return (
        <div>
            <table className="table">
                <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Price</th>
                    <th scope="col">Amount</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th scope="row">{props.cartList.map(c =>
                        <Item key={c.id} name={c.name}/>)} </th>
                    <td>{props.cartList.map(c =>
                        <Item key={c.id} name={c.description}/>)}</td>
                    <td>{props.cartList.map(c =>
                        <Item key={c.id} name={c.price}/>)}</td>
                    <td>{props.cartList.map(c =>
                        <Item key={c.id} name={c.amount}/>)}</td>
                </tr>
                </tbody>
            </table>

        </div>
    );
}

export default CartList;